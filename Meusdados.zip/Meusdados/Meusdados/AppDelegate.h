//
//  AppDelegate.h
//  Meusdados
//
//  Created by Usuário Convidado on 12/02/19.
//  Copyright © 2019 Usuário Convidado. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

