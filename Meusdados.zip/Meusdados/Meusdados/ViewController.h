//
//  ViewController.h
//  Meusdados
//
//  Created by Usuário Convidado on 12/02/19.
//  Copyright © 2019 Usuário Convidado. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    
    __weak IBOutlet UILabel *nome;
    __weak IBOutlet UILabel *idade;
    __weak IBOutlet UILabel *cidade;
}


- (IBAction)limpar:(id)sender;


- (IBAction)exibir:(id)sender;



@end

