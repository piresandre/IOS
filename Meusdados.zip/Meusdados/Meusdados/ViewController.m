//
//  ViewController.m
//  Meusdados
//
//  Created by Usuário Convidado on 12/02/19.
//  Copyright © 2019 Usuário Convidado. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    nome.text = @"Meu Nome é?";
    idade.text = @"Minha idade é?";
    cidade.text = @"Minha cidade é?";
}

- (IBAction)limpar:(id)sender {
    [self viewDidLoad];
//    nome.text = @"";
//    idade.text = @"";
//    cidade.text = @"";
    
}

- (IBAction)exibir:(id)sender {
    NSLog(@"Hello World");
    nome.text = @"André Pires";
    idade.text = @"19 anos";
    cidade.text = @"Sao Paulo";
}


@end
